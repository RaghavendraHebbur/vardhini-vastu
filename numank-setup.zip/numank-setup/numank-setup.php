<?php
/*
Plugin Name: Numank Website Setup
Description: Creates all Numank website pages with premium brand design.
Version: 3.0
Author: Raghavendrra Hebbur
*/

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_notices', 'nmk_show_button' );
function nmk_show_button() {
    $run_url   = wp_nonce_url( admin_url( '?nmk_run=1' ), 'nmk_run' );
    $reset_url = wp_nonce_url( admin_url( '?nmk_reset=1' ), 'nmk_reset' );
    if ( ! get_option( 'nmk_done' ) ) {
        echo '<div class="notice notice-warning"><p><strong>Numank:</strong> &mdash; <a href="' . esc_url( $run_url ) . '" class="button button-primary">Create All Website Pages Now</a></p></div>';
    } else {
        echo '<div class="notice notice-success is-dismissible"><p><strong>Numank Setup Complete!</strong> <a href="' . esc_url( home_url() ) . '" target="_blank">View Website &rarr;</a></p> <p><a href="' . esc_url( $reset_url ) . '" class="button">Re-run Setup (refresh all pages)</a></p></div>';
    }
}

add_action( 'admin_init', 'nmk_maybe_run' );
function nmk_maybe_run() {
    if ( isset( $_GET['nmk_run'] ) && check_admin_referer( 'nmk_run' ) && current_user_can( 'manage_options' ) ) {
        nmk_run_all();
    }
    if ( isset( $_GET['nmk_reset'] ) && check_admin_referer( 'nmk_reset' ) && current_user_can( 'manage_options' ) ) {
        delete_option( 'nmk_done' );
        wp_redirect( admin_url() );
        exit;
    }
}

function nmk_run_all() {
    $ids = nmk_pages();
    nmk_site_settings( $ids );
    nmk_menu( $ids );
    nmk_blog_posts();
    update_option( 'nmk_done', 1 );
    wp_redirect( admin_url() );
    exit;
}

/* ===========================================
   STYLES
=========================================== */

add_action( 'wp_head', 'nmk_styles' );
function nmk_styles() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet">';
    echo '<style id="nmk-css">' . nmk_css() . '</style>';
}

function nmk_css() {
    return '
:root {
  --d:  #160f06;
  --d2: #1e1509;
  --d3: #271b0c;
  --cr: #f2ede4;
  --cr2:#e8e1d5;
  --gd: #c9a440;
  --gl: #e0bc5a;
  --gd2:#9a7b28;
  --tx: #1c1810;
  --tl: #ede5d8;
  --mu: #6b5c42;
  --ml: #9a8870;
  --bd: rgba(201,164,64,0.22);
  --bl: rgba(60,40,10,0.12);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:var(--cr);color:var(--tx);font-family:"Jost",sans-serif;font-size:16px;line-height:1.75}
h1,h2,h3,h4{font-family:"Cormorant Garamond",serif;line-height:1.25;font-weight:600}
p{line-height:1.8}
a{color:var(--gd);text-decoration:none;transition:color .2s}
a:hover{color:var(--gl)}
img{max-width:100%;height:auto;display:block}

/* HERO */
.nmk-hero{
  min-height:100vh;background:var(--d);
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  text-align:center;padding:140px 32px 100px;
  position:relative;overflow:hidden;
}
.nmk-hero::before{
  content:"";position:absolute;inset:0;
  background:radial-gradient(ellipse 70% 50% at 50% 45%,rgba(201,164,64,.09) 0%,transparent 70%),
    repeating-linear-gradient(0deg,transparent,transparent 59px,rgba(201,164,64,.04) 60px),
    repeating-linear-gradient(90deg,transparent,transparent 59px,rgba(201,164,64,.04) 60px);
  pointer-events:none;
}
.nmk-hero-in{position:relative;z-index:2;max-width:820px;margin:0 auto}
.nmk-eyebrow{
  display:inline-block;font-family:"Jost",sans-serif;
  font-size:10px;letter-spacing:5px;text-transform:uppercase;
  color:var(--gd);margin-bottom:24px;
}
.nmk-hero h1{font-size:clamp(3rem,7vw,6rem);font-weight:700;color:#fff;letter-spacing:-1px;margin-bottom:8px}
.nmk-hero h1 em{color:var(--gd);font-style:normal}
.nmk-tagline{
  font-family:"Cormorant Garamond",serif;font-size:clamp(1.2rem,2.5vw,1.6rem);
  font-style:italic;color:var(--ml);margin-bottom:20px;
}
.nmk-rule-h{width:80px;height:1px;background:linear-gradient(90deg,transparent,var(--gd),transparent);margin:20px auto 36px}
.nmk-hero-sub{font-size:1rem;color:var(--ml);max-width:560px;margin:0 auto 52px;letter-spacing:.3px}
.nmk-stats{display:flex;justify-content:center;gap:60px;flex-wrap:wrap;margin-bottom:52px}
.nmk-stat strong{display:block;font-family:"Cormorant Garamond",serif;font-size:3rem;font-weight:700;color:var(--gd);line-height:1}
.nmk-stat span{font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--ml);display:block;margin-top:6px}

/* BUTTONS */
.nmk-btn,.nmk-btn-o,.nmk-btn-dk{
  display:inline-flex;align-items:center;gap:8px;
  padding:14px 36px;font-family:"Jost",sans-serif;
  font-weight:500;font-size:11px;letter-spacing:3px;text-transform:uppercase;
  transition:all .3s;cursor:pointer;text-decoration:none;border:1px solid var(--gd);
}
.nmk-btn{background:var(--gd);color:var(--d)}
.nmk-btn:hover{background:var(--gl);color:var(--d);border-color:var(--gl);box-shadow:0 4px 24px rgba(201,164,64,.35)}
.nmk-btn-o{background:transparent;color:var(--gd)}
.nmk-btn-o:hover{background:var(--gd);color:var(--d)}
.nmk-btn-dk{background:transparent;color:var(--tx);border-color:var(--tx)}
.nmk-btn-dk:hover{background:var(--tx);color:var(--cr)}
.nmk-brow{display:flex;gap:16px;justify-content:center;flex-wrap:wrap}

/* SECTION */
.nmk-s{padding:96px 32px;max-width:1160px;margin:0 auto}
.nmk-sh{margin-bottom:64px}
.nmk-sh.c{text-align:center}
.nmk-sh h2{font-size:clamp(2rem,4vw,3.2rem);color:inherit;margin-bottom:12px}
.nmk-sh h2 em{color:var(--gd);font-style:normal}
.nmk-sh p{font-size:1rem;color:var(--mu);max-width:560px}
.nmk-sh.c p{margin:0 auto}
.nmk-rule{width:48px;height:1px;background:var(--gd);margin:20px 0}
.nmk-sh.c .nmk-rule{margin:20px auto}

/* SHORT HERO */
.nmk-short{
  background:var(--d);padding:140px 32px 80px;
  text-align:center;position:relative;overflow:hidden;
}
.nmk-short::before{
  content:"";position:absolute;inset:0;
  background:radial-gradient(ellipse 60% 50% at 50% 50%,rgba(201,164,64,.07) 0%,transparent 70%);
  pointer-events:none;
}
.nmk-short-in{position:relative;z-index:2;max-width:720px;margin:0 auto}
.nmk-short h1{font-size:clamp(2.2rem,5vw,4rem);color:#fff;margin-bottom:12px}
.nmk-short h1 em{color:var(--gd);font-style:normal}
.nmk-short p{color:var(--ml);font-size:1.05rem}

/* GRID CARDS */
.nmk-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:1px;border:1px solid var(--bl);background:var(--bl);
}
.nmk-card{background:var(--cr);padding:44px 36px;transition:background .3s}
.nmk-card:hover{background:var(--cr2)}
.nmk-card-n{
  font-family:"Cormorant Garamond",serif;font-size:3rem;font-weight:700;
  color:var(--gd);opacity:.45;line-height:1;margin-bottom:16px;
}
.nmk-card h3{font-size:1.4rem;color:var(--tx);margin-bottom:12px}
.nmk-card p{color:var(--mu);font-size:.95rem}
.nmk-card .nmk-btn-dk{margin-top:24px;font-size:10px;padding:10px 24px}

/* SPLIT */
.nmk-split{display:grid;grid-template-columns:1fr 1.4fr;gap:80px;align-items:center}
.nmk-split-img{position:relative}
.nmk-split-img img{width:100%;border:1px solid var(--bl)}
.nmk-split-img::after{
  content:"";position:absolute;top:16px;left:16px;right:-16px;bottom:-16px;
  border:1px solid var(--gd);opacity:.3;pointer-events:none;z-index:-1;
}
.nmk-badges{display:flex;flex-wrap:wrap;gap:8px;margin-top:20px}
.nmk-badge{
  font-size:10px;letter-spacing:2px;text-transform:uppercase;
  color:var(--gd);border:1px solid var(--bd);padding:5px 14px;
}

/* QUOTE */
.nmk-quote{background:var(--d);padding:64px 48px;border-left:3px solid var(--gd)}
.nmk-quote blockquote{
  font-family:"Cormorant Garamond",serif;font-size:clamp(1.3rem,3vw,2rem);
  font-style:italic;color:var(--tl);line-height:1.6;margin:0;border:none;padding:0;
}
.nmk-quote blockquote em{color:var(--gd)}

/* TESTIMONIALS */
.nmk-tgrid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
  gap:1px;background:var(--bl);border:1px solid var(--bl);
}
.nmk-tc{background:var(--cr);padding:40px 32px}
.nmk-stars{color:var(--gd);font-size:.9rem;letter-spacing:4px;margin-bottom:20px}
.nmk-tc blockquote{
  font-family:"Cormorant Garamond",serif;font-size:1.15rem;
  font-style:italic;color:var(--tx);line-height:1.7;margin:0 0 20px;border:none;padding:0;
}
.nmk-tc-name{font-weight:600;font-size:.85rem;letter-spacing:1px;color:var(--tx)}
.nmk-tc-loc{font-size:.8rem;color:var(--mu)}

/* STEPS */
.nmk-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:48px}
.nmk-step{text-align:center;padding:0 16px}
.nmk-step-n{
  width:56px;height:56px;border:1px solid var(--gd);border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:"Cormorant Garamond",serif;font-size:1.4rem;font-weight:700;
  color:var(--gd);margin:0 auto 20px;
}
.nmk-step h3{font-size:1.2rem;margin-bottom:8px}
.nmk-step p{font-size:.9rem;opacity:.7}

/* FAQ */
.nmk-faqs{max-width:760px;margin:0 auto}
.nmk-faq{border-bottom:1px solid var(--bl);padding:28px 0}
.nmk-fq{
  font-family:"Cormorant Garamond",serif;font-size:1.2rem;font-weight:600;
  color:var(--tx);margin-bottom:12px;
  display:flex;justify-content:space-between;align-items:flex-start;gap:16px;
}
.nmk-fq span{color:var(--gd);font-size:1rem;flex-shrink:0;margin-top:3px}
.nmk-fa{color:var(--mu);font-size:.95rem;line-height:1.8}

/* CONTACT */
.nmk-ci{display:flex;align-items:flex-start;gap:20px;margin-bottom:32px}
.nmk-ci-ico{
  width:44px;height:44px;border:1px solid var(--bl);
  display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;
}
.nmk-ci-text small{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--mu);display:block;margin-bottom:4px}
.nmk-ci-text a,.nmk-ci-text strong{color:var(--tx);font-weight:600;font-size:1rem}
.nmk-ci-text a:hover{color:var(--gd)}

/* CTA */
.nmk-cta{
  background:var(--d);padding:96px 48px;text-align:center;
  border-top:1px solid var(--bd);border-bottom:1px solid var(--bd);
}
.nmk-cta h2{font-size:clamp(2rem,4vw,3.2rem);color:#fff;margin-bottom:16px}
.nmk-cta h2 em{color:var(--gd);font-style:normal}
.nmk-cta p{color:var(--ml);font-size:1rem;margin-bottom:40px;max-width:500px;margin-left:auto;margin-right:auto}

/* FLOATING WA */
.nmk-wa{
  position:fixed;bottom:28px;right:28px;width:58px;height:58px;
  background:#25d366;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 4px 20px rgba(37,211,102,.4);z-index:9999;
  transition:all .3s;text-decoration:none;
}
.nmk-wa:hover{transform:scale(1.1);background:#1fb659}
.nmk-wa svg{width:30px;height:30px;fill:#fff}

/* NAV - Astra theme overrides */
.site-header,.main-header-bar,.ast-primary-header-bar,#masthead{
  background:var(--d) !important;border-bottom:1px solid var(--bd) !important;box-shadow:none !important;
}
.ast-site-identity .site-title a,.site-title a{
  font-family:"Cormorant Garamond",serif !important;color:var(--gd) !important;
  font-size:1.5rem !important;font-weight:600 !important;letter-spacing:3px !important;text-transform:uppercase !important;
}
.main-header-menu .menu-item>a,.main-navigation ul li a,
.ast-builder-menu-1 .menu-item>a,#primary-menu>li>a{
  color:var(--tl) !important;font-family:"Jost",sans-serif !important;
  font-size:11px !important;font-weight:500 !important;
  letter-spacing:2px !important;text-transform:uppercase !important;transition:color .2s !important;
}
.main-header-menu .menu-item>a:hover,.main-navigation ul li a:hover{
  color:var(--gd) !important;background:transparent !important;
}
.main-header-menu .sub-menu,.main-navigation .sub-menu{
  background:var(--d2) !important;border:1px solid var(--bd) !important;
  border-top:2px solid var(--gd) !important;box-shadow:0 8px 32px rgba(0,0,0,.5) !important;
  padding:8px 0 !important;min-width:220px !important;
}
.main-header-menu .sub-menu .menu-item a,.main-navigation .sub-menu li a{
  color:var(--ml) !important;font-size:10px !important;
  letter-spacing:2px !important;padding:10px 20px !important;
  border-bottom:1px solid rgba(201,164,64,.07) !important;
}
.main-header-menu .sub-menu .menu-item a:hover,.main-navigation .sub-menu li a:hover{
  color:var(--gd) !important;background:var(--d3) !important;
}
.ast-mobile-menu-trigger,.ast-menu-toggle{color:var(--gd) !important}
.ast-mobile-nav-wrap{background:var(--d) !important}
.site-footer,.ast-small-footer,#colophon{
  background:var(--d) !important;border-top:1px solid var(--bd) !important;
  color:var(--ml) !important;font-family:"Jost",sans-serif !important;
  font-size:.8rem !important;letter-spacing:1px !important;
}
.site-footer a{color:var(--gd) !important}
.entry-header{display:none !important}
.entry-content,.ast-article-single{padding:0 !important;margin:0 !important}
.page .entry-content>p:empty{display:none}

/* RESPONSIVE */
@media(max-width:900px){
  .nmk-split{grid-template-columns:1fr;gap:40px}
  .nmk-split-img::after{display:none}
}
@media(max-width:640px){
  .nmk-s{padding:64px 24px}
  .nmk-hero{padding:120px 24px 80px}
  .nmk-short{padding:120px 24px 60px}
  .nmk-cta{padding:64px 24px}
  .nmk-stats{gap:32px}
  .nmk-btn,.nmk-btn-o,.nmk-btn-dk{padding:12px 28px;font-size:10px}
  .nmk-quote{padding:48px 28px}
}
    ';
}

/* ===========================================
   FLOATING WHATSAPP
=========================================== */

add_action( 'wp_footer', 'nmk_wa_btn' );
function nmk_wa_btn() {
    echo '<a href="https://wa.me/919739105574" class="nmk-wa" target="_blank" rel="noopener" aria-label="WhatsApp">';
    echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';
    echo '</a>';
}

/* ===========================================
   SETTINGS
=========================================== */

function nmk_site_settings( $ids ) {
    if ( isset( $ids['home'] ) ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $ids['home'] );
    }
    if ( isset( $ids['blog'] ) ) {
        update_option( 'page_for_posts', $ids['blog'] );
    }
    update_option( 'blogname', 'Numank' );
    update_option( 'blogdescription', 'Where Numbers Reveal Destiny — Expert Numerology by Raghavendrra Hebbur' );
}

/* ===========================================
   PAGES
=========================================== */

function nmk_pages() {
    $pages = array(
        'home'         => array( 'Home',                    'nmk_pg_home' ),
        'about'        => array( 'About',                   'nmk_pg_about' ),
        'consultation' => array( 'Personal Consultation',   'nmk_pg_consult' ),
        'name'         => array( 'Name Correction',         'nmk_pg_name' ),
        'business'     => array( 'Business Numerology',     'nmk_pg_biz' ),
        'baby'         => array( 'Baby Name Numerology',    'nmk_pg_baby' ),
        'mobile'       => array( 'Mobile Number Numerology','nmk_pg_mobile' ),
        'vastu'        => array( 'Vastu Consultation',      'nmk_pg_vastu' ),
        'courses'      => array( 'Numerology Courses',      'nmk_pg_courses' ),
        'testimonials' => array( 'Testimonials',            'nmk_pg_testimonials' ),
        'faq'          => array( 'FAQ',                     'nmk_pg_faq' ),
        'contact'      => array( 'Contact',                 'nmk_pg_contact' ),
        'blog'         => array( 'Blog',                    'nmk_pg_blog' ),
    );
    $ids = array();
    foreach ( $pages as $key => $data ) {
        $content  = call_user_func( $data[1] );
        $existing = get_page_by_path( sanitize_title( $data[0] ) );
        if ( $existing ) {
            wp_update_post( array(
                'ID'           => $existing->ID,
                'post_content' => $content,
                'post_status'  => 'publish',
            ) );
            $ids[ $key ] = $existing->ID;
        } else {
            $id = wp_insert_post( array(
                'post_title'   => $data[0],
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => sanitize_title( $data[0] ),
            ) );
            if ( ! is_wp_error( $id ) ) { $ids[ $key ] = $id; }
        }
    }
    return $ids;
}

/* ===========================================
   MENU - Services dropdown
=========================================== */

function nmk_menu( $ids ) {
    $name = 'Main Menu';
    $mid  = wp_create_nav_menu( $name );
    if ( is_wp_error( $mid ) ) {
        $obj = get_term_by( 'name', $name, 'nav_menu' );
        if ( $obj ) { $mid = $obj->term_id; } else { return; }
    }

    if ( isset( $ids['home'] ) ) {
        wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => 'Home', 'menu-item-object' => 'page', 'menu-item-object-id' => $ids['home'], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
    }
    if ( isset( $ids['about'] ) ) {
        wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => 'About', 'menu-item-object' => 'page', 'menu-item-object-id' => $ids['about'], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
    }

    $svc_id = wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => 'Services', 'menu-item-url' => '#', 'menu-item-type' => 'custom', 'menu-item-status' => 'publish' ) );

    $children = array(
        'consultation' => 'Personal Consultation',
        'name'         => 'Name Correction',
        'business'     => 'Business Numerology',
        'baby'         => 'Baby Name Numerology',
        'mobile'       => 'Mobile Number',
        'vastu'        => 'Vastu Consultation',
    );
    foreach ( $children as $key => $label ) {
        if ( isset( $ids[ $key ] ) ) {
            wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $ids[ $key ], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish', 'menu-item-parent-id' => $svc_id ) );
        }
    }

    $top = array( 'courses' => 'Courses', 'testimonials' => 'Testimonials', 'blog' => 'Blog', 'contact' => 'Contact' );
    foreach ( $top as $key => $label ) {
        if ( isset( $ids[ $key ] ) ) {
            wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $ids[ $key ], 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
        }
    }

    $locs = get_theme_mod( 'nav_menu_locations' );
    if ( ! is_array( $locs ) ) { $locs = array(); }
    $locs['primary'] = $mid;
    $locs['menu-1']  = $mid;
    set_theme_mod( 'nav_menu_locations', $locs );
}

/* ===========================================
   BLOG POSTS
=========================================== */

function nmk_blog_posts() {
    $posts = array(
        array( 'What Is Numerology? A Complete Guide to the Power of Numbers', '<p>Numerology is the ancient metaphysical science of numbers — the study of how numbers influence your personality, destiny, relationships, and life path. Rooted in Chaldean and Pythagorean traditions, numerology reveals the hidden vibration behind your name and birth date. Your Life Path Number, Destiny Number, and Soul Urge Number all work together to paint a complete picture of who you are. Book a personal numerology consultation with Raghavendrra Hebbur — Call or WhatsApp: +91 97391 05574.</p>' ),
        array( 'How Name Correction in Numerology Can Transform Your Life', '<p>Your name carries a specific numerical vibration that interacts with your birth date every single day. When these vibrations are misaligned, you may experience repeated setbacks in career, relationships, or finances without understanding why. Name correction numerology by Raghavendrra Hebbur analyzes your full name using Chaldean and Pythagorean systems and recommends subtle spelling adjustments. Call +91 97391 05574 to book today.</p>' ),
        array( 'Business Numerology: Choose the Right Name and Launch Date for Success', '<p>In business, timing and naming are everything. Numerology helps entrepreneurs choose business names, registration dates, and brand identities that resonate with success frequencies. Raghavendrra Hebbur has helped 1,200+ clients align their business decisions with numerological principles. Contact Numank at +91 97391 05574.</p>' ),
        array( 'Baby Name Numerology: Give Your Child the Gift of a Harmonious Name', '<p>A baby name is the most important gift parents can give. In Vedic and Chaldean numerology traditions, a name aligned with the child birth date and birth star creates a life of harmony, success, and positive energy. Raghavendrra Hebbur specializes in baby name selection. WhatsApp +91 97391 05574 to schedule your consultation.</p>' ),
        array( 'Is Your Mobile Number Attracting or Blocking Success?', '<p>Your mobile number is more than just digits — it is a constant energetic frequency you carry everywhere. Numbers out of harmony with your personal numerology can create subtle blocks in communication, deals, and relationships. Get your number analyzed — WhatsApp +91 97391 05574.</p>' ),
    );
    foreach ( $posts as $p ) {
        $existing = get_page_by_title( $p[0], OBJECT, 'post' );
        if ( ! $existing ) {
            wp_insert_post( array( 'post_title' => $p[0], 'post_content' => $p[1], 'post_status' => 'publish', 'post_type' => 'post' ) );
        }
    }
}

/* ===========================================
   PAGE CONTENT
=========================================== */

function nmk_pg_home() {
    return '
<div class="nmk-hero">
<div class="nmk-hero-in">
  <span class="nmk-eyebrow">&#10022; Sacred Numerology Science &#10022;</span>
  <h1>Where Numbers<br><em>Reveal Destiny</em></h1>
  <p class="nmk-tagline">"Every number surrounding you is a conversation the universe is having with you."</p>
  <div class="nmk-rule-h"></div>
  <p class="nmk-hero-sub">Expert Chaldean &amp; Pythagorean Numerology by <strong style="color:#fff">Raghavendrra Hebbur</strong> &mdash; helping 1,200+ souls unlock their true potential since 2019.</p>
  <div class="nmk-stats">
    <div class="nmk-stat"><strong>5+</strong><span>Years of Practice</span></div>
    <div class="nmk-stat"><strong>1,200+</strong><span>Happy Clients</span></div>
    <div class="nmk-stat"><strong>6</strong><span>Core Services</span></div>
    <div class="nmk-stat"><strong>98%</strong><span>Satisfaction Rate</span></div>
  </div>
  <div class="nmk-brow">
    <a href="/contact" class="nmk-btn">Book Consultation</a>
    <a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp Now</a>
  </div>
</div>
</div>

<div class="nmk-s">
  <div class="nmk-sh c">
    <span class="nmk-eyebrow">What We Offer</span>
    <h2>Our <em>Services</em></h2>
    <div class="nmk-rule"></div>
    <p>Every number in your life carries a divine message. We decode it for you.</p>
  </div>
  <div class="nmk-grid">
    <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Personal Consultation</h3><p>Decode your Life Path, Destiny &amp; Soul Urge numbers for clarity in love, career &amp; life decisions.</p><a href="/personal-consultation" class="nmk-btn-dk">Explore</a></div>
    <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Name Correction</h3><p>Align your name vibration with your birth date for unstoppable harmony and success.</p><a href="/name-correction" class="nmk-btn-dk">Explore</a></div>
    <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Business Numerology</h3><p>Choose the right business name, launch date &amp; number for maximum prosperity.</p><a href="/business-numerology" class="nmk-btn-dk">Explore</a></div>
    <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Baby Name Numerology</h3><p>Give your newborn a harmonious name aligned with their birth star and destiny.</p><a href="/baby-name-numerology" class="nmk-btn-dk">Explore</a></div>
    <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Mobile Number Analysis</h3><p>Find out if your mobile number is attracting or blocking opportunities in your life.</p><a href="/mobile-number-numerology" class="nmk-btn-dk">Explore</a></div>
    <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Vastu Consultation</h3><p>Harmonize your living and workspace energies using ancient Vastu Shastra principles.</p><a href="/vastu-consultation" class="nmk-btn-dk">Explore</a></div>
  </div>
</div>

<div style="background:var(--cr2)">
<div class="nmk-s">
  <div class="nmk-split">
    <div class="nmk-split-img">
      <img src="https://numank.com/wp-content/uploads/2026/04/unnamed-1.png" alt="Raghavendrra Hebbur Numerologist" />
      <div class="nmk-badges">
        <span class="nmk-badge">Chaldean Numerology</span>
        <span class="nmk-badge">Pythagorean</span>
        <span class="nmk-badge">Vastu Shastra</span>
        <span class="nmk-badge">Name Correction</span>
      </div>
    </div>
    <div>
      <span class="nmk-eyebrow">Your Guide</span>
      <h2>Meet <em>Raghavendrra Hebbur</em></h2>
      <div class="nmk-rule"></div>
      <p style="color:var(--mu);margin-bottom:16px">With over 5 years of dedicated practice in Chaldean and Pythagorean numerology, Raghavendrra has transformed the lives of 1,200+ clients across India and internationally.</p>
      <p style="color:var(--mu);margin-bottom:32px">Also an expert Vastu consultant featured on <strong style="color:var(--tx)">vardhinivastu.com</strong> and <strong style="color:var(--tx)">vastuone.com</strong>, Raghavendrra brings a holistic approach combining numerology with spatial energy for complete life transformation.</p>
      <a href="/about" class="nmk-btn-dk">Know More About Me</a>
    </div>
  </div>
</div>
</div>

<div class="nmk-quote">
  <div style="max-width:800px;margin:0 auto">
    <blockquote>"Every number that surrounds you &mdash; your birth date, your name, your address &mdash; is a <em>conversation the universe is having with you.</em> Numank teaches you to listen."</blockquote>
    <p style="color:var(--gd);font-size:.8rem;letter-spacing:3px;text-transform:uppercase;margin-top:24px">&#8212; Raghavendrra Hebbur</p>
  </div>
</div>

<div class="nmk-s">
  <div class="nmk-sh c">
    <span class="nmk-eyebrow">How It Works</span>
    <h2>Your Journey to <em>Clarity</em></h2>
    <div class="nmk-rule"></div>
  </div>
  <div class="nmk-steps">
    <div class="nmk-step"><div class="nmk-step-n">1</div><h3>Book Your Session</h3><p style="color:var(--mu)">Call or WhatsApp +91 97391 05574 to schedule your personal consultation.</p></div>
    <div class="nmk-step"><div class="nmk-step-n">2</div><h3>Share Your Details</h3><p style="color:var(--mu)">Provide your full name and date of birth for accurate chart calculation.</p></div>
    <div class="nmk-step"><div class="nmk-step-n">3</div><h3>Receive Your Report</h3><p style="color:var(--mu)">Get a detailed numerology report with insights and recommendations.</p></div>
    <div class="nmk-step"><div class="nmk-step-n">4</div><h3>Transform Your Life</h3><p style="color:var(--mu)">Implement the guidance and experience positive changes in 21 to 40 days.</p></div>
  </div>
</div>

<div style="background:var(--cr2)">
<div class="nmk-s">
  <div class="nmk-sh c">
    <span class="nmk-eyebrow">Client Stories</span>
    <h2>What Our <em>Clients Say</em></h2>
    <div class="nmk-rule"></div>
  </div>
  <div class="nmk-tgrid" style="margin-top:48px">
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"After name correction by Raghavendrra, I got a promotion within 3 months. The change was almost magical."</blockquote><div class="nmk-tc-name">Priya Sharma</div><div class="nmk-tc-loc">Bangalore</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"My business was struggling for 2 years. After the name correction and auspicious date selection, things turned around completely."</blockquote><div class="nmk-tc-name">Vikram Nair</div><div class="nmk-tc-loc">Chennai</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"The baby name consultation was so detailed. Raghavendrra gave us 5 beautiful options with full analysis. We are so grateful."</blockquote><div class="nmk-tc-name">Meena &amp; Suresh Patel</div><div class="nmk-tc-loc">Ahmedabad</div></div>
  </div>
</div>
</div>

<div class="nmk-cta">
  <span class="nmk-eyebrow" style="color:var(--gd)">Ready?</span>
  <h2>Unlock Your <em>True Potential</em></h2>
  <p>Book a personal numerology consultation today and start your journey toward clarity, success, and harmony.</p>
  <div class="nmk-brow">
    <a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a>
    <a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp Us</a>
  </div>
</div>
    ';
}

function nmk_pg_about() {
    return '
<div class="nmk-short">
<div class="nmk-short-in">
  <span class="nmk-eyebrow">Your Numerologist</span>
  <h1>About <em>Raghavendrra Hebbur</em></h1>
  <p>5+ Years | 1,200+ Clients | Chaldean &amp; Pythagorean Numerology Expert</p>
</div>
</div>
<div class="nmk-s">
  <div class="nmk-split">
    <div class="nmk-split-img">
      <img src="https://numank.com/wp-content/uploads/2026/04/unnamed-1.png" alt="Raghavendrra Hebbur Numerologist" />
      <div class="nmk-badges" style="margin-top:20px">
        <span class="nmk-badge">Chaldean Numerology</span><span class="nmk-badge">Pythagorean</span><span class="nmk-badge">Vastu Shastra</span><span class="nmk-badge">Name Correction</span><span class="nmk-badge">Baby Names</span>
      </div>
    </div>
    <div>
      <span class="nmk-eyebrow">My Story</span>
      <h2>From Seeker to <em>Guide</em></h2>
      <div class="nmk-rule"></div>
      <p style="color:var(--mu);margin-bottom:16px">Raghavendrra Hebbur is a certified numerologist and Vastu consultant based in India, with over 5 years of dedicated practice helping individuals and businesses align with their highest potential through the science of numbers.</p>
      <p style="color:var(--mu);margin-bottom:16px">His journey into numerology began as a personal quest for answers and what he discovered transformed not just his own life but the lives of over 1,200 clients. His approach combines both Chaldean and Pythagorean numerology systems, providing a comprehensive reading that goes beyond surface-level interpretation.</p>
      <p style="color:var(--mu);margin-bottom:32px">As a recognized Vastu expert featured on <strong style="color:var(--tx)">vardhinivastu.com</strong> and <strong style="color:var(--tx)">vastuone.com</strong>, Raghavendrra uniquely integrates spatial energy alignment with numerological insights for complete life transformation.</p>
      <div class="nmk-brow" style="justify-content:flex-start">
        <a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a>
        <a href="https://wa.me/919739105574" class="nmk-btn-dk" target="_blank">WhatsApp</a>
      </div>
    </div>
  </div>
</div>
<div style="background:var(--cr2)">
<div class="nmk-s">
  <div class="nmk-sh c"><span class="nmk-eyebrow">Expertise</span><h2>Areas of <em>Specialisation</em></h2><div class="nmk-rule"></div></div>
  <div class="nmk-grid">
    <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Life Path Analysis</h3><p>Deep decode of your Life Path, Destiny, and Soul Urge numbers for complete self-understanding.</p></div>
    <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Name Correction</h3><p>Spelling corrections that align your name vibration with your birth chart for maximum harmony.</p></div>
    <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Business Numerology</h3><p>Name selection, launch dates, and number analysis for business success.</p></div>
    <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Baby Names</h3><p>Harmonious names aligned with the child birth star and family numerology.</p></div>
    <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Mobile Number</h3><p>Is your phone number working for or against you? Find out and fix it.</p></div>
    <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Vastu Consultation</h3><p>Balance the energies of your home and office for health, wealth, and happiness.</p></div>
  </div>
</div>
</div>
<div class="nmk-cta"><h2>Start Your <em>Transformation</em> Today</h2><p>Every great journey begins with one step. Take yours now.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call Now</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_consult() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Core Service</span><h1>Personal <em>Numerology Consultation</em></h1><p>Unlock the hidden blueprint of your life through your name and birth date</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Book Now &mdash; +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-sh c"><span class="nmk-eyebrow">What You Get</span><h2>Numbers That <em>Define You</em></h2><div class="nmk-rule"></div></div>
<div class="nmk-grid">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Life Path Number</h3><p>Your most important number revealing your core purpose, natural talents, and the main theme of your entire lifetime.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Destiny Number</h3><p>Derived from your full name, this shows the skills you must develop to fulfill your life mission.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Soul Urge Number</h3><p>The deepest desire of your heart and what truly motivates you beneath the surface of everyday life.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Personality Number</h3><p>How others perceive you and your outer personality presentation to the world.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Personal Year Cycle</h3><p>What this year holds for you including career moves, relationship shifts, opportunities, and challenges ahead.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Compatibility Analysis</h3><p>Numerological compatibility with partners, business associates, and family members.</p></div>
</div></div>
<div style="background:var(--cr2)"><div class="nmk-s"><div class="nmk-sh c"><span class="nmk-eyebrow">The Process</span><h2>How Your Consultation <em>Works</em></h2><div class="nmk-rule"></div></div>
<div class="nmk-steps"><div class="nmk-step"><div class="nmk-step-n">1</div><h3>Book</h3><p style="color:var(--mu)">WhatsApp or call +91 97391 05574 to schedule.</p></div><div class="nmk-step"><div class="nmk-step-n">2</div><h3>Share</h3><p style="color:var(--mu)">Provide your full birth name and date of birth.</p></div><div class="nmk-step"><div class="nmk-step-n">3</div><h3>Receive</h3><p style="color:var(--mu)">Get your detailed report within 24 to 48 hours.</p></div><div class="nmk-step"><div class="nmk-step-n">4</div><h3>Consult</h3><p style="color:var(--mu)">One-on-one session to walk through findings.</p></div></div>
</div></div>
<div class="nmk-cta"><h2>Book Your <em>Personal Consultation</em></h2><p>Call or WhatsApp Raghavendrra Hebbur today. Same-day consultations available.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_name() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Name Correction Science</span><h1>Numerology <em>Name Correction</em></h1><p>A single letter change in your name can shift your entire life trajectory</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Get Name Corrected</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-sh c"><span class="nmk-eyebrow">Why Name Correction</span><h2>Your Name Is Your <em>Vibration</em></h2><div class="nmk-rule"></div><p>Every letter in your name carries a numerical value. When your name total number is incompatible with your birth date, you experience invisible friction causing repeated setbacks, missed opportunities, and unexplained struggles.</p></div>
<div class="nmk-grid" style="margin-top:48px">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Career Acceleration</h3><p>Many clients report faster promotions, new opportunities, and professional recognition after name correction.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Financial Harmony</h3><p>Aligning your name number with your birth number removes energetic blocks around money and abundance.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Better Relationships</h3><p>Corrected name vibrations improve interpersonal harmony in marriage, family, and professional relationships.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Health &amp; Wellbeing</h3><p>Numbers affect your energy field. A harmonious name supports better physical and mental health.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Luck &amp; Timing</h3><p>When your numbers align, you naturally find yourself in the right place at the right time more often.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Academic Success</h3><p>Students with corrected name numbers often show improved focus, memory, and academic results.</p></div>
</div></div>
<div class="nmk-cta"><h2>Get Your Name <em>Corrected Today</em></h2><p>Join 1,200+ clients who transformed their lives through numerology name correction.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_biz() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">For Entrepreneurs &amp; Companies</span><h1>Business <em>Numerology</em></h1><p>Name your business for success. Launch on the right date. Build on powerful numbers.</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Consult for Business</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-grid">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Business Name Selection</h3><p>Choose a business name whose numerological value aligns with your personal numbers and business goals.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Auspicious Launch Dates</h3><p>Select the most powerful dates for registration, launch events, product releases, and major decisions.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Lucky Number Strategy</h3><p>Incorporate power numbers into your pricing, addresses, phone numbers, and brand identity.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Partner Compatibility</h3><p>Analyze numerological compatibility of business partners and key team members for harmonious partnerships.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Brand Rebranding Audit</h3><p>Is your existing business name blocking your growth? Get a numerological audit and rebranding recommendation.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Domain &amp; Brand Analysis</h3><p>Ensure your website domain, brand colors, and logo number align with your business numerology.</p></div>
</div></div>
<div class="nmk-cta"><h2>Build a <em>Numerologically Aligned</em> Business</h2><p>Do not leave your business success to chance. Contact Raghavendrra Hebbur for your business numerology consultation.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_baby() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">A Lifelong Gift</span><h1>Baby Name <em>Numerology</em></h1><p>Give your child a name that vibrates with harmony, health, and lasting success</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Get Baby Names</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-sh c"><span class="nmk-eyebrow">Why It Matters</span><h2>A Name That <em>Blesses for Life</em></h2><div class="nmk-rule"></div><p>In Vedic and numerological traditions, a child name is their most powerful tool. A numerologically aligned name sets the foundation for health, intelligence, success, and happiness throughout their life.</p></div>
<div class="nmk-grid" style="margin-top:48px">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Birth Star Alignment</h3><p>Names selected in harmony with the child Nakshatra (birth star) for Vedic compatibility.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Birth Date Harmony</h3><p>The name total value aligns with the child birth date number for lifelong positive energy.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Family Compatibility</h3><p>Names checked for compatibility with parents and siblings numbers for family harmony.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Multiple Options</h3><p>Receive 5 to 10 carefully analyzed name options across different Chaldean number values.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Positive Life Themes</h3><p>Each suggested name is analyzed for the life themes it attracts: success, health, wisdom, joy.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Detailed Report</h3><p>Every suggested name comes with a full numerological explanation so you can make an informed choice.</p></div>
</div></div>
<div class="nmk-cta"><h2>Give Your Baby the <em>Perfect Name</em></h2><p>Contact Raghavendrra Hebbur for a comprehensive baby name consultation. WhatsApp preferred.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_mobile() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Mobile Number Science</span><h1>Mobile Number <em>Numerology</em></h1><p>Your phone number is broadcasting a frequency 24/7 &mdash; is it working for you?</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Analyze My Number</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-grid">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Number Compatibility Check</h3><p>We calculate your mobile number root value and check its compatibility with your personal numerology chart.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Detailed Analysis</h3><p>Each digit in your number carries weight. We analyze the full sequence for its collective and individual impact.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Career &amp; Business Impact</h3><p>Certain number combinations can block deals, communication, and professional relationships without your knowledge.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Personal Life Influence</h3><p>Your mobile number affects social connections and relationship energies more than you realize.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Recommended Numbers</h3><p>If your current number is unfavorable, we provide specific number combinations to look for when changing.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Written Report</h3><p>Receive a clear written analysis of your mobile number numerological impact with practical recommendations.</p></div>
</div></div>
<div class="nmk-cta"><h2>Is Your Mobile Number <em>Lucky for You?</em></h2><p>WhatsApp your mobile number to Raghavendrra Hebbur for a quick compatibility check.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_vastu() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Ancient Spatial Science</span><h1>Vastu <em>Consultation</em></h1><p>Align your home and workspace with cosmic energies for health, wealth, and peace</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Book Vastu Consult</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-grid">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Home Vastu</h3><p>Complete analysis of your home directional energies, room placements, and energy flow for family harmony.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Office &amp; Business Vastu</h3><p>Optimize your workspace layout for productivity, prosperity, and positive team dynamics.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>New Property Guidance</h3><p>Before buying or building, get a numerology plus Vastu analysis of the property and plot number.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Remedies Without Demolition</h3><p>Practical Vastu corrections using colors, elements, and positioning with no structural changes needed in most cases.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Five Elements Balance</h3><p>Ensure Earth, Water, Fire, Air, and Space are balanced in your environment for optimal living energy.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Numerology + Vastu Combo</h3><p>Unique service combining your personal numerology with Vastu analysis for complete life alignment.</p></div>
</div></div>
<div class="nmk-cta"><h2>Transform Your Space, <em>Transform Your Life</em></h2><p>Raghavendrra Hebbur is a featured expert on vardhinivastu.com and vastuone.com. Book your Vastu consultation today.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_courses() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Learn the Science</span><h1>Numerology <em>Courses</em></h1><p>Master the ancient science of numbers and transform your own life and others too</p><div style="margin-top:32px" class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Enquire About Courses</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div></div>
<div class="nmk-s"><div class="nmk-grid">
  <div class="nmk-card"><div class="nmk-card-n">01</div><h3>Beginner Numerology</h3><p>Learn the fundamentals: Life Path, Destiny, and Soul Urge numbers. Calculate and interpret your own chart.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">02</div><h3>Advanced Numerology</h3><p>Deep dive into Chaldean numerology, Personal Year cycles, Karmic numbers, and advanced chart reading.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">03</div><h3>Professional Practitioner</h3><p>Become a certified numerology practitioner. Learn to conduct client consultations professionally.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">04</div><h3>Business Numerology Course</h3><p>Specialized training in business name analysis, launch date selection, and entrepreneurial numerology.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">05</div><h3>Online &amp; Offline</h3><p>Flexible learning options including in person attendance or online sessions from anywhere.</p></div>
  <div class="nmk-card"><div class="nmk-card-n">06</div><h3>Certification</h3><p>Receive a recognized certificate upon course completion to establish your credentials as a numerologist.</p></div>
</div></div>
<div class="nmk-cta"><h2>Start Your Journey as a <em>Numerology Expert</em></h2><p>Contact Raghavendrra Hebbur for the next course batch schedule and enrollment details.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_testimonials() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">1,200+ Happy Clients</span><h1>Client <em>Testimonials</em></h1><p>Real stories from real people whose lives transformed through numerology</p></div></div>
<div class="nmk-s">
  <div class="nmk-tgrid">
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"After name correction by Raghavendrra, I got a promotion within 3 months. The shift was remarkable and I am forever grateful."</blockquote><div class="nmk-tc-name">Priya Sharma</div><div class="nmk-tc-loc">Bangalore, Karnataka</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"My business was struggling for 2 years. After the business name correction and auspicious date selection, revenue doubled in 6 months."</blockquote><div class="nmk-tc-name">Vikram Nair</div><div class="nmk-tc-loc">Chennai, Tamil Nadu</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"The baby name consultation was so detailed and reassuring. Raghavendrra gave us 5 beautiful options with full analysis. So grateful."</blockquote><div class="nmk-tc-name">Meena &amp; Suresh Patel</div><div class="nmk-tc-loc">Ahmedabad, Gujarat</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"Changed my mobile number as recommended. Within weeks I started receiving better business calls and deals. Simply amazing!"</blockquote><div class="nmk-tc-name">Rajan Krishnamurthy</div><div class="nmk-tc-loc">Hyderabad, Telangana</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"The Vastu and Numerology combined consultation changed everything in my home. We feel more peaceful and our finances have improved."</blockquote><div class="nmk-tc-name">Sunita &amp; Mohan Gupta</div><div class="nmk-tc-loc">Delhi</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"I was skeptical at first but Raghavendrra accuracy in reading my chart was stunning. He told me things he had no way of knowing."</blockquote><div class="nmk-tc-name">Anil Bhat</div><div class="nmk-tc-loc">Mumbai, Maharashtra</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"The personal year forecast was spot on. Everything he predicted for 2025 came true. Now I plan all major decisions with his guidance."</blockquote><div class="nmk-tc-name">Kavitha Reddy</div><div class="nmk-tc-loc">Pune, Maharashtra</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"My career was stuck for years. After the name correction and numerology guidance, I got two job offers in the same month!"</blockquote><div class="nmk-tc-name">Suresh Kumar</div><div class="nmk-tc-loc">Coimbatore, Tamil Nadu</div></div>
    <div class="nmk-tc"><div class="nmk-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div><blockquote>"Registered my company on the lucky date suggested by Raghavendrra. Best decision I ever made. Business is thriving beyond expectations!"</blockquote><div class="nmk-tc-name">Deepak Joshi</div><div class="nmk-tc-loc">Jaipur, Rajasthan</div></div>
  </div>
</div>
<div class="nmk-cta"><h2>Your Success Story <em>Starts Here</em></h2><p>Join 1,200+ happy clients. Book your consultation with Raghavendrra Hebbur today.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_faq() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Got Questions?</span><h1>Frequently Asked <em>Questions</em></h1><p>Everything you need to know about numerology and our services</p></div></div>
<div class="nmk-s">
  <div class="nmk-faqs">
    <div class="nmk-faq"><div class="nmk-fq">What is numerology and how does it work? <span>&#10022;</span></div><div class="nmk-fa">Numerology is the study of numbers and their cosmic vibration. Every number from 1 to 9 carries a unique energy frequency. Your name and birth date together create a unique numerical blueprint that influences your personality, career, relationships, and life events.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">Which numerology system do you use, Chaldean or Pythagorean? <span>&#10022;</span></div><div class="nmk-fa">Raghavendrra Hebbur uses both Chaldean and Pythagorean systems. Chaldean numerology is used for name analysis as it is considered more accurate for vibration. Pythagorean is used for life path and destiny calculations. Together they provide the most complete picture.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">How quickly will I see results after name correction? <span>&#10022;</span></div><div class="nmk-fa">Most clients begin to notice subtle positive shifts within 21 to 40 days of consistently using the corrected name. Major life changes such as career breakthroughs and relationship improvements are typically reported within 3 to 6 months.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">Do I need to legally change my name for numerology name correction? <span>&#10022;</span></div><div class="nmk-fa">Not necessarily. The name correction primarily involves how you sign your name and introduce yourself. You can start using the corrected spelling in your signature, visiting cards, social media, and email. The energy shift begins immediately even without a legal change.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">Can numerology be done online or over the phone? <span>&#10022;</span></div><div class="nmk-fa">Absolutely. All of our services can be delivered fully online via phone call or WhatsApp. You share your birth details and Raghavendrra sends you a detailed written report followed by a live discussion session.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">Is numerology compatible with my religion or beliefs? <span>&#10022;</span></div><div class="nmk-fa">Numerology is a universal science and is not aligned with any particular religion. People of all faiths and backgrounds benefit from numerological insights. It is a tool for self-understanding and practical life guidance.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">How is baby name numerology consultation done? <span>&#10022;</span></div><div class="nmk-fa">You share the baby date of birth, birth star (Nakshatra) if known, and parents names and birth dates. Raghavendrra then prepares 5 to 10 compatible name options with full numerological analysis for each so you can make an informed and confident choice.</div></div>
    <div class="nmk-faq"><div class="nmk-fq">What is the consultation fee? <span>&#10022;</span></div><div class="nmk-fa">Consultation fees vary by service type. Please WhatsApp or call +91 97391 05574 for current pricing. Custom packages are available for families and businesses needing multiple services.</div></div>
  </div>
</div>
<div class="nmk-cta"><h2>Still Have <em>Questions?</em></h2><p>WhatsApp or call Raghavendrra Hebbur directly. He personally responds to every inquiry.</p><div class="nmk-brow"><a href="tel:+919739105574" class="nmk-btn">Call +91 97391 05574</a><a href="https://wa.me/919739105574" class="nmk-btn-o" target="_blank">WhatsApp</a></div></div>
    ';
}

function nmk_pg_contact() {
    return '
<div class="nmk-short"><div class="nmk-short-in"><span class="nmk-eyebrow">Get in Touch</span><h1>Contact <em>Raghavendrra</em></h1><p>Ready to transform your life? Reach out today &mdash; same-day responses guaranteed</p></div></div>
<div class="nmk-s">
  <div class="nmk-split">
    <div>
      <span class="nmk-eyebrow">Direct Contact</span>
      <h2 style="margin-bottom:36px">Let Us <em>Connect</em></h2>
      <div class="nmk-ci"><div class="nmk-ci-ico">&#128222;</div><div class="nmk-ci-text"><small>Call Us</small><a href="tel:+919739105574">+91 97391 05574</a></div></div>
      <div class="nmk-ci"><div class="nmk-ci-ico">&#128172;</div><div class="nmk-ci-text"><small>WhatsApp</small><a href="https://wa.me/919739105574" target="_blank">+91 97391 05574</a></div></div>
      <div class="nmk-ci"><div class="nmk-ci-ico">&#127758;</div><div class="nmk-ci-text"><small>Website</small><strong>numank.com</strong></div></div>
      <div class="nmk-ci"><div class="nmk-ci-ico">&#128336;</div><div class="nmk-ci-text"><small>Consultation Hours</small><strong>Mon to Sat: 9 AM to 7 PM IST</strong></div></div>
      <div style="margin-top:40px;padding:32px;background:var(--cr2);border:1px solid var(--bl)">
        <p style="font-size:10px;letter-spacing:3px;text-transform:uppercase;color:var(--mu);margin-bottom:12px">Fastest Response</p>
        <p style="color:var(--mu);font-size:.95rem;margin-bottom:20px">WhatsApp is the quickest way to reach Raghavendrra. Share your name and date of birth to get started immediately.</p>
        <a href="https://wa.me/919739105574?text=Hello%20Raghavendrra%2C%20I%20want%20to%20book%20a%20numerology%20consultation" class="nmk-btn" target="_blank">Start WhatsApp Chat</a>
      </div>
    </div>
    <div>
      <span class="nmk-eyebrow">Services Available</span>
      <h2 style="margin-bottom:36px">What We <em>Offer</em></h2>
      <div class="nmk-grid">
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">01</div><h3 style="font-size:1.1rem">Personal Consultation</h3></div>
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">02</div><h3 style="font-size:1.1rem">Name Correction</h3></div>
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">03</div><h3 style="font-size:1.1rem">Business Numerology</h3></div>
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">04</div><h3 style="font-size:1.1rem">Baby Names</h3></div>
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">05</div><h3 style="font-size:1.1rem">Mobile Number</h3></div>
        <div class="nmk-card" style="padding:28px"><div class="nmk-card-n" style="font-size:2rem">06</div><h3 style="font-size:1.1rem">Vastu Consultation</h3></div>
      </div>
    </div>
  </div>
</div>
    ';
}

function nmk_pg_blog() {
    return '<p>Read our latest articles on numerology, Vastu, name correction, and more below.</p>';
}
